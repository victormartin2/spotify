<script setup>
import { ref } from 'vue';
</script>

<template>
  <div class="search-view">
    <h1>Buscar</h1>
    <p>Aquí podrás buscar tus canciones y artistas favoritos.</p>
  </div>
</template>

<style scoped>
.search-view {
  padding: 24px;
  color: white;
}
</style>
