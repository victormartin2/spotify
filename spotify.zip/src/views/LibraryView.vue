<script setup>
import { ref } from 'vue';
</script>

<template>
  <div class="library-view">
    <h1>Tu biblioteca</h1>
    <p>Aquí encontrarás tus listas de reproducción y podcasts guardados.</p>
  </div>
</template>

<style scoped>
.library-view {
  padding: 24px;
  color: white;
}
</style>
