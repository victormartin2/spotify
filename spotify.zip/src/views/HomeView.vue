<script setup>
// Home view is just a wrapper for MainContent
</script>

<template>
  <div class="home-view">
    <!-- MainContent is rendered in App.vue -->
  </div>
</template>

<style scoped>
.home-view {
  width: 100%;
  height: 100%;
}
</style>
